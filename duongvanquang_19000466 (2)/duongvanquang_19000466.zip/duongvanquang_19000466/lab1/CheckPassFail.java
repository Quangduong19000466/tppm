package lab1;

public class CheckPassFail { // Save as "CheckPassFail.java"
        public static void main(String[] args) { // Program entry point
            int mark = 49; // Set the value of "mark" here!
            System.out.println("The mark is " + mark);
// if-else statement
            if (mark>=50 ) {
                System.out.println("Pass");
            } else {
                System.out.println("Fail");
            }
            System.out.println("Done");
        }
    }

